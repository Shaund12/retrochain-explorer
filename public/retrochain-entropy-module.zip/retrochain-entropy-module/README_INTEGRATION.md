# RetroChain RetroEntropy Module (x/entropy)

This package adds a native, chain-level randomness beacon module designed for games (slots, loot, raffles)
and a very "RetroChain" feel: it emits an *Entropy Pulse* event with fun "arcade reels" derived from each beacon.

## What you get (v1)
- `MsgSubmitBeacon`: relayers submit drand Quicknet beacons (signature + round). Chain stores:
  - round
  - signature (bytes)
  - randomness = SHA-256(signature)
  - ingest height + time
- Queries:
  - `LatestBeacon`
  - `Beacon(round)`
  - `Params`
  - `StreamRandomness(stream_id, height, seed, round_opt)` => domain-separated deterministic 32-byte value
- Events:
  - `entropy_pulse` with:
    - round
    - randomness_hex
    - reels (3 emoji)
    - ingest_height

## Drop-in steps (RetroChain repo)
1) Copy folders into your repo:
   - `x/entropy/*`  ->  `<retrochain repo>/x/entropy/*`
   - `proto/retrochain/entropy/*` -> `<retrochain repo>/proto/retrochain/entropy/*`

2) Generate protobuf Go code (your repo already has buf config):
   - run your existing proto generator command (commonly one of these):
     - `make proto-gen`
     - `make proto`
     - `buf generate`
   The protos in this module set `go_package = "retrochain/x/entropy/types"` so the generated code lands in
   `x/entropy/types`.

3) Wire the module into the app (SDK 0.53 depinject/appconfig style):
   - Add the module proto to your app config list if you maintain one (often `app/app_config.go` or `app/app.go`).
   - Ensure the module is included in ModuleManager initialization, and that `RegisterServices` is called.

   If you already have modules like `arcade`, `burn`, etc wired via depinject with `appconfig.Register(...)`,
   this module follows the same pattern in `x/entropy/module/depinject.go`.

4) Add genesis default:
   - The module provides `DefaultGenesis()` in `x/entropy/types/genesis.go`.
   - If you maintain a custom genesis builder, include `entropy` like your other modules.

## Quick test flow (after wiring)
1) Add yourself as a relayer (genesis params) or via authority MsgUpdateParams.
2) Submit a beacon:
   - `retrochaind tx entropy submit-beacon <round> <hex_signature> --from <relayer>`
3) Query:
   - `retrochaind query entropy latest-beacon`
   - `retrochaind query entropy stream-randomness arcade <height> <seed_hex>`

## Notes
- v1 does **not** verify the BLS signature on-chain; it is designed to be fast and immediately useful.
  You can upgrade later to on-chain BLS verification without breaking the query API by simply adding verification in MsgSubmitBeacon.
- Default params are prefilled for drand Quicknet (chain hash + period + genesis time).
