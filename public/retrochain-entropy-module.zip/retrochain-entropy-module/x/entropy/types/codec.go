package types

import (
  sdk "github.com/cosmos/cosmos-sdk/types"
  cdctypes "github.com/cosmos/cosmos-sdk/codec/types"
  "github.com/cosmos/cosmos-sdk/types/msgservice"
)

// RegisterInterfaces wires Msg + service descriptors.
// The `_Msg_serviceDesc` symbol is generated from `tx.proto` after you run proto generation.
func RegisterInterfaces(registry cdctypes.InterfaceRegistry) {
  registry.RegisterImplementations((*sdk.Msg)(nil),
    &MsgSubmitBeacon{},
    &MsgUpdateParams{},
  )

  msgservice.RegisterMsgServiceDesc(registry, &_Msg_serviceDesc)
}
