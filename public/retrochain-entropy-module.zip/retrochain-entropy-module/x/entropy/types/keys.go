package types

const (
  ModuleName = "entropy"
  StoreKey   = ModuleName
  RouterKey  = ModuleName
  MemStoreKey = "mem_entropy"

  // store keys (byte prefixes)
  KeyParams = 0x01
  KeyLatestRound = 0x02
  KeyBeaconPrefix = 0x10
)

func BeaconKey(round uint64) []byte {
  // prefix | round(8)
  b := make([]byte, 1+8)
  b[0] = KeyBeaconPrefix
  PutU64(b[1:], round)
  return b
}

func LatestRoundKey() []byte { return []byte{KeyLatestRound} }
func ParamsKey() []byte { return []byte{KeyParams} }
