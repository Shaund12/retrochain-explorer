package types

import "cosmossdk.io/errors"

var (
  ErrUnauthorized      = errors.Register(ModuleName, 1, "unauthorized")
  ErrInvalidSignature  = errors.Register(ModuleName, 2, "invalid signature")
  ErrInvalidRound      = errors.Register(ModuleName, 3, "invalid round")
  ErrBeaconNotFound    = errors.Register(ModuleName, 4, "beacon not found")
  ErrParamsInvalid     = errors.Register(ModuleName, 5, "params invalid")
)
