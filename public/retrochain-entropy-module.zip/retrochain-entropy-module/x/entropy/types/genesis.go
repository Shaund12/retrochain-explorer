package types

// DefaultGenesis returns a default GenesisState.
// After proto codegen, GenesisState will be available in this package.
func DefaultGenesis() *GenesisState {
  p := DefaultParams()
  return &GenesisState{
    Params:     p,
    LatestRound: 0,
    Beacons:    []*Beacon{},
  }
}
