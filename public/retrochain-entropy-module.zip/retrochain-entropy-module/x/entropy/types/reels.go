package types

import "strings"

// ArcadeReels returns 3 emoji "reels" for UI candy.
// This is cosmetic and deterministic from randomness bytes.
func ArcadeReels(rand []byte) string {
  if len(rand) == 0 {
    return "🎰🎰🎰"
  }
  symbols := []string{"🍒", "🍋", "🔔", "💎", "⭐", "7️⃣", "👾", "🕹️", "🪙", "🔥", "⚡", "🎮"}
  pick := func(b byte) string { return symbols[int(b)%len(symbols)] }

  r1 := pick(rand[0])
  r2 := pick(rand[len(rand)/2])
  r3 := pick(rand[len(rand)-1])
  return strings.Join([]string{r1, r2, r3}, "")
}
