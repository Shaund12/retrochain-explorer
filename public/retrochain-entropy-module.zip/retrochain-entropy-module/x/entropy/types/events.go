package types

const (
  EventTypeEntropyPulse = "entropy_pulse"

  AttrRound        = "round"
  AttrRandHex      = "randomness_hex"
  AttrReels        = "reels"
  AttrIngestHeight = "ingest_height"
)
