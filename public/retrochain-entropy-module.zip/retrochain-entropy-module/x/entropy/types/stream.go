package types

import (
  "crypto/sha256"
  "encoding/binary"
)

var streamDomain = []byte("retrochain:entropy:v1")

// DeriveStreamRandomness returns 32 bytes deterministic randomness scoped to a stream.
func DeriveStreamRandomness(baseRand []byte, streamID string, height uint64, seed []byte) []byte {
  h := sha256.New()
  h.Write(streamDomain)
  h.Write([]byte{0})
  h.Write([]byte(streamID))
  h.Write([]byte{0})
  hb := make([]byte, 8)
  binary.BigEndian.PutUint64(hb, height)
  h.Write(hb)
  h.Write([]byte{0})
  h.Write(seed)
  h.Write([]byte{0})
  h.Write(baseRand)
  sum := h.Sum(nil)
  return sum
}
