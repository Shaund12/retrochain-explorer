package types

import (
  sdk "github.com/cosmos/cosmos-sdk/types"
)

// DefaultParams fills sensible defaults for drand Quicknet.
// Note: authority should be set by your app (gov module address or custom admin).
func DefaultParams() Params {
  return Params{
    Authority:         "",
    DrandChainHash:    "52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971",
    DrandBeaconId:     "quicknet",
    DrandGenesisTime:  1692803367,
    DrandPeriodSeconds: 3,
    Relayers:          []string{},
    MaxRoundAhead:     5, // allow small jitter
    SubmitFee:         sdk.NewInt64Coin("uretro", 0),
  }
}

func (p Params) ValidateBasic() error {
  // keep it light; your app can enforce stricter rules.
  if p.DrandPeriodSeconds == 0 {
    return ErrParamsInvalid
  }
  if p.DrandChainHash == "" {
    return ErrParamsInvalid
  }
  return nil
}
