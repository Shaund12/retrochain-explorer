package types

import (
  sdk "github.com/cosmos/cosmos-sdk/types"
)

type BankKeeper interface {
  SendCoinsFromAccountToModule(ctx sdk.Context, senderAddr sdk.AccAddress, recipientModule string, amt sdk.Coins) error
}
