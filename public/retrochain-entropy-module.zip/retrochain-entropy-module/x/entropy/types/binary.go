package types

import "encoding/binary"

func PutU64(dst []byte, v uint64) {
  binary.BigEndian.PutUint64(dst, v)
}

func GetU64(src []byte) uint64 {
  return binary.BigEndian.Uint64(src)
}
