package keeper

import (
  "context"
  "encoding/hex"
  "fmt"

  "cosmossdk.io/errors"
  sdk "github.com/cosmos/cosmos-sdk/types"

  "retrochain/x/entropy/types"
)

type msgServer struct {
  Keeper
}

var _ types.MsgServer = msgServer{}

func NewMsgServerImpl(k Keeper) types.MsgServer {
  return &msgServer{Keeper: k}
}

func (m msgServer) SubmitBeacon(goCtx context.Context, msg *types.MsgSubmitBeacon) (*types.MsgSubmitBeaconResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)

  if !m.IsRelayer(ctx, msg.Creator) {
    return nil, types.ErrUnauthorized
  }

  if msg.Round == 0 {
    return nil, errors.Wrap(types.ErrInvalidRound, "round must be > 0")
  }

  p := m.GetParams(ctx)
  if err := p.ValidateBasic(); err != nil {
    return nil, errors.Wrap(types.ErrParamsInvalid, "params invalid")
  }

  // Basic sanity against future rounds (prevents spamming nonsense).
  // expected_round ~= floor((blockTime - genesis_time)/period) + 1
  if p.DrandGenesisTime > 0 && p.DrandPeriodSeconds > 0 {
    bt := uint64(ctx.BlockTime().Unix())
    if bt > p.DrandGenesisTime {
      expected := ((bt - p.DrandGenesisTime) / p.DrandPeriodSeconds) + 1
      if msg.Round > expected+p.MaxRoundAhead {
        return nil, errors.Wrapf(types.ErrInvalidRound, "round too far ahead (expected ~%d)", expected)
      }
    }
  }

  sig, err := DecodeHexBytes(msg.SignatureHex)
  if err != nil || len(sig) < 32 {
    return nil, errors.Wrap(types.ErrInvalidSignature, "signature hex invalid")
  }

  // optional fee
  if p.SubmitFee.Denom != "" && p.SubmitFee.Amount.IsPositive() {
    relayer, err2 := sdk.AccAddressFromBech32(msg.Creator)
    if err2 != nil {
      return nil, err2
    }
    if err := m.bankKeeper.SendCoinsFromAccountToModule(ctx, relayer, types.ModuleName, sdk.NewCoins(p.SubmitFee)); err != nil {
      return nil, err
    }
  }

  b, err := m.IngestBeacon(ctx, msg.Round, sig)
  if err != nil {
    return nil, err
  }

  reels := types.ArcadeReels(b.Randomness)
  ctx.EventManager().EmitEvent(
    sdk.NewEvent(types.EventTypeEntropyPulse,
      sdk.NewAttribute(types.AttrRound, fmt.Sprintf("%d", b.Round)),
      sdk.NewAttribute(types.AttrRandHex, hex.EncodeToString(b.Randomness)),
      sdk.NewAttribute(types.AttrReels, reels),
      sdk.NewAttribute(types.AttrIngestHeight, fmt.Sprintf("%d", b.HeightIngested)),
    ),
  )

  return &types.MsgSubmitBeaconResponse{}, nil
}

func (m msgServer) UpdateParams(goCtx context.Context, msg *types.MsgUpdateParams) (*types.MsgUpdateParamsResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)

  // Authority check: if params.authority set use it; else keeper authority.
  current := m.GetParams(ctx)
  auth := current.Authority
  if auth == "" {
    auth = m.Authority()
  }
  if msg.Authority != auth {
    return nil, types.ErrUnauthorized
  }
  if err := msg.Params.ValidateBasic(); err != nil {
    return nil, types.ErrParamsInvalid
  }
  m.SetParams(ctx, msg.Params)
  return &types.MsgUpdateParamsResponse{}, nil
}
