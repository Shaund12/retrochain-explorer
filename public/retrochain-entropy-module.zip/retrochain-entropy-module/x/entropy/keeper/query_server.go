package keeper

import (
  "context"

  sdk "github.com/cosmos/cosmos-sdk/types"
  "retrochain/x/entropy/types"
)

var _ types.QueryServer = Keeper{}

func (k Keeper) Params(goCtx context.Context, _ *types.QueryParamsRequest) (*types.QueryParamsResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)
  p := k.GetParams(ctx)
  return &types.QueryParamsResponse{Params: p}, nil
}

func (k Keeper) LatestBeacon(goCtx context.Context, _ *types.QueryLatestBeaconRequest) (*types.QueryLatestBeaconResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)
  lr := k.GetLatestRound(ctx)
  if lr == 0 {
    return &types.QueryLatestBeaconResponse{Found: false}, nil
  }
  b, ok := k.GetBeacon(ctx, lr)
  if !ok {
    return &types.QueryLatestBeaconResponse{Found: false}, nil
  }
  return &types.QueryLatestBeaconResponse{Beacon: b, Found: true}, nil
}

func (k Keeper) Beacon(goCtx context.Context, req *types.QueryBeaconRequest) (*types.QueryBeaconResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)
  b, ok := k.GetBeacon(ctx, req.Round)
  if !ok {
    return &types.QueryBeaconResponse{Found: false}, nil
  }
  return &types.QueryBeaconResponse{Beacon: b, Found: true}, nil
}

func (k Keeper) StreamRandomness(goCtx context.Context, req *types.QueryStreamRandomnessRequest) (*types.QueryStreamRandomnessResponse, error) {
  ctx := sdk.UnwrapSDKContext(goCtx)

  round := req.Round
  if round == 0 {
    round = k.GetLatestRound(ctx)
  }
  b, ok := k.GetBeacon(ctx, round)
  if !ok {
    return nil, types.ErrBeaconNotFound
  }

  out := types.DeriveStreamRandomness(b.Randomness, req.StreamId, req.Height, req.Seed)
  return &types.QueryStreamRandomnessResponse{
    Randomness: out,
    RoundUsed: round,
  }, nil
}
