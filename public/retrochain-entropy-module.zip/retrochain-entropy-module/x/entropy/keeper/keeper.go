package keeper

import (
  "crypto/sha256"
  "encoding/hex"
  "strings"
  "time"

  "cosmossdk.io/core/store"
  storetypes "cosmossdk.io/store/types"
  "github.com/cosmos/cosmos-sdk/codec"
  sdk "github.com/cosmos/cosmos-sdk/types"
  "google.golang.org/protobuf/types/known/timestamppb"

  "retrochain/x/entropy/types"
)

type Keeper struct {
  cdc codec.Codec
  storeService store.KVStoreService
  bankKeeper types.BankKeeper

  authority string
}

func NewKeeper(cdc codec.Codec, storeService store.KVStoreService, bankKeeper types.BankKeeper, authority string) Keeper {
  return Keeper{
    cdc: cdc,
    storeService: storeService,
    bankKeeper: bankKeeper,
    authority: authority,
  }
}

func (k Keeper) Store(ctx sdk.Context) storetypes.KVStore {
  return k.storeService.OpenKVStore(ctx)
}

func (k Keeper) Authority() string {
  // if params has authority, you can migrate to that; keeper authority is used for bootstrap.
  return k.authority
}

func (k Keeper) GetParams(ctx sdk.Context) types.Params {
  store := k.Store(ctx)
  bz := store.Get(types.ParamsKey())
  if bz == nil {
    return types.DefaultParams()
  }
  var p types.Params
  k.cdc.MustUnmarshal(bz, &p)
  return p
}

func (k Keeper) SetParams(ctx sdk.Context, p types.Params) {
  bz := k.cdc.MustMarshal(&p)
  k.Store(ctx).Set(types.ParamsKey(), bz)
}

func (k Keeper) IsRelayer(ctx sdk.Context, addr string) bool {
  p := k.GetParams(ctx)
  for _, r := range p.Relayers {
    if r == addr {
      return true
    }
  }
  return false
}

func (k Keeper) GetLatestRound(ctx sdk.Context) uint64 {
  bz := k.Store(ctx).Get(types.LatestRoundKey())
  if bz == nil || len(bz) != 8 {
    return 0
  }
  return types.GetU64(bz)
}

func (k Keeper) SetLatestRound(ctx sdk.Context, round uint64) {
  bz := make([]byte, 8)
  types.PutU64(bz, round)
  k.Store(ctx).Set(types.LatestRoundKey(), bz)
}

func (k Keeper) SetBeacon(ctx sdk.Context, b *types.Beacon) {
  bz := k.cdc.MustMarshal(b)
  k.Store(ctx).Set(types.BeaconKey(b.Round), bz)
}

func (k Keeper) GetBeacon(ctx sdk.Context, round uint64) (*types.Beacon, bool) {
  bz := k.Store(ctx).Get(types.BeaconKey(round))
  if bz == nil {
    return nil, false
  }
  var b types.Beacon
  k.cdc.MustUnmarshal(bz, &b)
  return &b, true
}

func DecodeHexBytes(s string) ([]byte, error) {
  s = strings.TrimSpace(strings.ToLower(s))
  s = strings.TrimPrefix(s, "0x")
  return hex.DecodeString(s)
}

func (k Keeper) IngestBeacon(ctx sdk.Context, round uint64, sig []byte) (*types.Beacon, error) {
  // randomness = sha256(signature)
  sum := sha256.Sum256(sig)

  now := ctx.BlockTime()
  if now.IsZero() {
    now = time.Now().UTC()
  }

  b := &types.Beacon{
    Round: round,
    Signature: sig,
    Randomness: sum[:],
    HeightIngested: uint64(ctx.BlockHeight()),
    TimeIngested: timestamppb.New(now),
  }

  k.SetBeacon(ctx, b)

  if round > k.GetLatestRound(ctx) {
    k.SetLatestRound(ctx, round)
  }
  return b, nil
}
