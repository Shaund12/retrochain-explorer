package module

import (
  "encoding/json"

  "cosmossdk.io/core/appmodule"
  "github.com/cosmos/cosmos-sdk/codec"
  cdctypes "github.com/cosmos/cosmos-sdk/codec/types"
  sdk "github.com/cosmos/cosmos-sdk/types"
  "github.com/cosmos/cosmos-sdk/types/module"

  "retrochain/x/entropy/keeper"
  "retrochain/x/entropy/types"
)

var (
  _ module.AppModule      = AppModule{}
  _ module.AppModuleBasic = AppModule{}
  _ appmodule.AppModule   = AppModule{}
)

type AppModule struct {
  cdc    codec.Codec
  keeper keeper.Keeper
}

func NewAppModule(cdc codec.Codec, k keeper.Keeper) AppModule {
  return AppModule{cdc: cdc, keeper: k}
}

func (AppModule) Name() string { return types.ModuleName }

func (AppModule) RegisterLegacyAminoCodec(_ *codec.LegacyAmino) {}

func (AppModule) RegisterInterfaces(reg cdctypes.InterfaceRegistry) {
  types.RegisterInterfaces(reg)
}

func (AppModule) DefaultGenesis(cdc codec.JSONCodec) json.RawMessage {
  return cdc.MustMarshalJSON(types.DefaultGenesis())
}

func (AppModule) ValidateGenesis(cdc codec.JSONCodec, _ sdk.TxEncodingConfig, bz json.RawMessage) error {
  var gs types.GenesisState
  if err := cdc.UnmarshalJSON(bz, &gs); err != nil {
    return err
  }
  return gs.Params.ValidateBasic()
}

func (am AppModule) RegisterServices(cfg module.Configurator) {
  types.RegisterMsgServer(cfg.MsgServer(), keeper.NewMsgServerImpl(am.keeper))
  types.RegisterQueryServer(cfg.QueryServer(), am.keeper)
}

// --- Genesis (optional hooks; wire these if your app template uses them) ---

func (am AppModule) InitGenesis(ctx sdk.Context, cdc codec.JSONCodec, bz json.RawMessage) {
  var gs types.GenesisState
  cdc.MustUnmarshalJSON(bz, &gs)

  am.keeper.SetParams(ctx, gs.Params)
  if gs.LatestRound > 0 {
    am.keeper.SetLatestRound(ctx, gs.LatestRound)
  }
  for _, b := range gs.Beacons {
    am.keeper.SetBeacon(ctx, b)
  }
}

func (am AppModule) ExportGenesis(ctx sdk.Context, cdc codec.JSONCodec) json.RawMessage {
  p := am.keeper.GetParams(ctx)
  lr := am.keeper.GetLatestRound(ctx)

  // export latest only (keeps genesis small; adjust if you want full history)
  beacons := []*types.Beacon{}
  if lr > 0 {
    if b, ok := am.keeper.GetBeacon(ctx, lr); ok {
      beacons = append(beacons, b)
    }
  }

  gs := types.GenesisState{Params: p, LatestRound: lr, Beacons: beacons}
  return cdc.MustMarshalJSON(&gs)
}

func (AppModule) IsAppModule() {}
