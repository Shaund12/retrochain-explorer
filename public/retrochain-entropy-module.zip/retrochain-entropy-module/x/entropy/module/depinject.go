package module

import (
  "cosmossdk.io/core/appmodule"
  "cosmossdk.io/core/address"
  "cosmossdk.io/core/store"
  "cosmossdk.io/depinject"
  "cosmossdk.io/depinject/appconfig"
  "github.com/cosmos/cosmos-sdk/codec"

  "retrochain/x/entropy/keeper"
  "retrochain/x/entropy/types"
)

var _ depinject.OnePerModuleType = AppModule{}

func (AppModule) IsOnePerModuleType() {}

func init() {
  appconfig.Register(
    &types.Module{},
    appconfig.Provide(ProvideModule),
  )
}

type ModuleInputs struct {
  depinject.In

  Config       *types.Module
  StoreService store.KVStoreService
  Cdc          codec.Codec
  AddressCodec address.Codec

  BankKeeper types.BankKeeper
}

type ModuleOutputs struct {
  depinject.Out

  EntropyKeeper keeper.Keeper
  Module        appmodule.AppModule
}

func ProvideModule(in ModuleInputs) ModuleOutputs {
  // Authority: if module config has authority use it; else empty (set via params/genesis).
  authority := ""
  if in.Config != nil {
    authority = in.Config.Authority
  }

  k := keeper.NewKeeper(in.Cdc, in.StoreService, in.BankKeeper, authority)

  m := NewAppModule(in.Cdc, k)

  return ModuleOutputs{
    EntropyKeeper: k,
    Module:        m,
  }
}
