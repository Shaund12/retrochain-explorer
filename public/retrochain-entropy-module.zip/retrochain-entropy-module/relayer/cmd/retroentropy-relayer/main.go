package main

import (
  "context"
  "encoding/hex"
  "encoding/json"
  "fmt"
  "net/http"
  "os"
  "time"
)

// This is a lightweight template relayer. It intentionally avoids SDK client wiring so you can
// integrate it with your existing client setup (many chains already have helper scripts).
//
// It shows how to pull the latest round+signature from drand v2 HTTP API.
// You'll still need to broadcast a tx to RetroChain (use your existing CLI or client libs).

type drandLatest struct {
  Round      uint64 `json:"round"`
  Signature  string `json:"signature"` // base64url in v2; depending on endpoint
  Randomness string `json:"randomness"`
}

func main() {
  api := os.Getenv("DRAND_API")
  if api == "" { api = "https://api.drand.sh" }

  chain := os.Getenv("DRAND_CHAIN_HASH")
  if chain == "" {
    chain = "52db9ba70e0cc0f6eaf7803dd07447a1f5477735fd3f661792ba94600c84e971"
  }

  // v2 endpoint: /v2/chains/:chain-hash/rounds/latest
  url := fmt.Sprintf("%s/v2/chains/%s/rounds/latest", api, chain)

  ctx := context.Background()
  client := &http.Client{Timeout: 10 * time.Second}

  for {
    req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)
    resp, err := client.Do(req)
    if err != nil {
      fmt.Println("drand fetch error:", err)
      time.Sleep(3 * time.Second)
      continue
    }
    var out map[string]any
    _ = json.NewDecoder(resp.Body).Decode(&out)
    _ = resp.Body.Close()

    // The response shape may vary; print it so you can adapt quickly.
    b, _ := json.MarshalIndent(out, "", "  ")
    fmt.Println(string(b))

    // NOTE:
    // To submit on-chain:
    // - Extract round (uint64) and signature bytes from the response.
    // - Convert signature bytes to hex.
    // - Broadcast: `retrochaind tx entropy submit-beacon <round> <sig_hex> --from <relayer> ...`
    //
    // For now we just show how to fetch.
    _ = hex.EncodeToString([]byte{}) // keep import used in template
    time.Sleep(3 * time.Second)
  }
}
