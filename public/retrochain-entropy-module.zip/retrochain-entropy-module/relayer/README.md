# RetroEntropy Relayer (optional)

This small relayer polls drand Quicknet and submits `MsgSubmitBeacon` to RetroChain.

It is optional, but it's the easiest way to keep your chain's entropy fresh.

## Build
After you wire the module and run proto generation in your RetroChain repo, copy this relayer folder anywhere and:
- set env vars (see below)
- `go build ./cmd/retroentropy-relayer`

## Env vars
- `RC_RPC`  : tendermint RPC URL (e.g. http://127.0.0.1:26657)
- `RC_GRPC` : gRPC URL (e.g. 127.0.0.1:9090)
- `RC_CHAIN_ID`
- `RC_KEY_NAME` : key in your local keyring
- `DRAND_API` : default https://api.drand.sh (v2)
- `DRAND_CHAIN_HASH` : quicknet chain hash (default in module)
